<?php include  $g['path_layout'].$d['layout']['dir'].'/_cross/top.php'?>
<div id="content">
	<div class="wrap">
	<?php include __KIMS_CONTENT__?>
	</div>
</div>
<?php include  $g['path_layout'].$d['layout']['dir'].'/_cross/bottom.php'?>
