
<?php if($_style_):?>
<div style="<?php echo $_style_?>">
<?php include __KIMS_CONTENT__?>
</div>
<?php else:?>
<?php include __KIMS_CONTENT__?>
<?php endif?>
