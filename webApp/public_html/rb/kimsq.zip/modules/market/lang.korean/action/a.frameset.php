
<script type="text/javascript">
top.getId('marketFrame').style.height = '<?php echo $height?>px';
</script>
<?php exit?>