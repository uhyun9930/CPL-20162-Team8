<?php
$d['amenu']['config'] = '설정';
$d['amenu']['main'] = '마켓';
$d['amenu']['request'] = '추천';
$d['amenu']['brand'] = '브랜드';
$d['amenu']['buyer'] = '구매함';
$d['amenu']['pack'] = '패키지';
?>