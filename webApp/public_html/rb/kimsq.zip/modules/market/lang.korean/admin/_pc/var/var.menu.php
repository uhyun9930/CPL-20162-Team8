<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['config'] = '환경설정';
$d['amenu']['main'] = '큐마켓';
$d['amenu']['request'] = '맞춤상품';
$d['amenu']['brand'] = '브랜드샵';
$d['amenu']['buyer'] = '구매내역';
$d['amenu']['pack'] = '패키지설치';
?>