<?php
$d['bbs']['skin_main'] = "_pc/list01";
$d['bbs']['skin_mobile'] = "_mobile/mobile01";
$d['bbs']['skin_total'] = "_pc/list01";
$d['bbs']['rss'] = "1";
$d['bbs']['restr'] = "RE:";
$d['bbs']['replydel'] = "";
$d['bbs']['commentdel'] = "";
$d['bbs']['badword'] = "시발,씨발,개새끼,개세끼,개쉐이,지랄,니미,좆,좃,조낸,죽어,쪽바리,짱개,떼놈,";
$d['bbs']['badword_action'] = "0";
$d['bbs']['badword_escape'] = "*";
$d['bbs']['singo_del'] = "";
$d['bbs']['singo_del_num'] = "20";
$d['bbs']['singo_del_act'] = "1";
$d['bbs']['recnum'] = "20";
$d['bbs']['sbjcut'] = "40";
$d['bbs']['newtime'] = "24";
?>