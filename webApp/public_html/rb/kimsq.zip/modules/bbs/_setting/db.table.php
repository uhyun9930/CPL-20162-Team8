<?php
$table[$module.'list'] = $DB['head'].'_'.$module.'_list'; //게시판리스트
$table[$module.'idx']  = $DB['head'].'_'.$module.'_index'; //게시판인덱스
$table[$module.'data'] = $DB['head'].'_'.$module.'_data'; //게시판데이터
$table[$module.'month']= $DB['head'].'_'.$module.'_month'; //월별수량
$table[$module.'day']  = $DB['head'].'_'.$module.'_day'; //일별수량
$table[$module.'xtra'] = $DB['head'].'_'.$module.'_xtra'; //확장데이터
?>