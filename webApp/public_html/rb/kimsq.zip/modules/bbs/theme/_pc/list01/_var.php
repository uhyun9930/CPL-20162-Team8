<?php
//목록
$d['theme']['use_rss'] = "1"; //rss발행사용(사용=1/사용안함=0)
$d['theme']['show_catnum'] = "1"; //분류별등록수출력(출력=1/감춤=0)
$d['theme']['pagenum'] = "10"; //페이지스킵숫자갯수
$d['theme']['search'] = "1"; //검색폼출력(출력=1/감춤=0)

//본문
$d['theme']['date_viewf'] = "Y.m.d H:i"; //날짜포맷
$d['theme']['use_singo'] = "1"; //신고사용(사용=1/사용안함=0)
$d['theme']['use_print'] = "1"; //인쇄사용(사용=1/사용안함=0)
$d['theme']['use_scrap'] = "1"; //스크랩사용(사용=1/사용안함=0)
$d['theme']['use_font'] = "1"; //글꼴사용(사용=1/사용안함=0)
$d['theme']['use_trackback'] = "1"; //엮인글사용(사용=1/사용안함=0)
$d['theme']['use_reply'] = "1"; //답변사용(사용=1/사용안함=0)
$d['theme']['use_autoresize'] = "1"; //이미지 자동리사이즈(사용=1/사용안함=0)
$d['theme']['show_tag'] = "1"; //태그출력(출력=1/감춤=0)
$d['theme']['show_upfile'] = "1"; //첨부파일출력(출력=1/감춤=0)
$d['theme']['show_score1'] = "0"; //공감출력(출력=1/감춤=0)-회원전용
$d['theme']['show_score2'] = "0"; //공감출력(출력=1/감춤=0)-회원전용
$d['theme']['show_list'] = "1"; //열람시리스트출력(출력=1/감춤=0)
$d['theme']['snsping'] = "1"; //SNS보내기출력(출력=1/감춤=0)

//글쓰기
$d['theme']['edit_html'] = "0"; //위지위그에디터 사용등급(레벨넘버이상,0이면 비회원허용)
$d['theme']['edit_height'] = "450"; //글쓰기폼높이(픽셀)
$d['theme']['show_edittool2'] = "1"; //편집기아이콘출력(출력=1/감춤=0)
$d['theme']['perm_upload'] = "1"; //파일첨부권한(등급이상)
$d['theme']['perm_photo'] = "1"; //사진첨부권한(등급이상)
$d['theme']['show_wtag'] = "1"; //태그필드출력(출력=1/감춤=0)
$d['theme']['show_trackback'] = "1"; //엮인글필드출력(출력=1/감춤=0)
$d['theme']['use_hidden'] = "1"; //비밀글(사용안함=0/유저선택사용=1/무조건비밀글=2)
?>