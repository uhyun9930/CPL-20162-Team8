<?php
$d['amenu']['config'] = '기초환경';
$d['amenu']['main'] = '게시판';
?>