<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['config'] = '기초환경';
$d['amenu']['main'] = '게시판관리';
$d['amenu']['post'] = '게시물관리';
$d['amenu']['skin'] = '테마';
?>