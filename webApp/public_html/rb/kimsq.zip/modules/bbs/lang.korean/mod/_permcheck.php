


<div id="guidebox">

	<h1>서비스 안내</h1>
	
	<ul>
	<li>요청하신 페이지는 권한이 있어야 접근하실 수 있습니다.</li>
	<li>로그인하신 후에 이용하세요.</li>
	<li>로그인을 하신 후에도 이 페이지가 출력되면 회원등급 권한이 없는 경우입니다.</li>
	</ul>

	<div class="back">
		<input type="button" value="돌아가기" class="btngray" onclick="history.back();" />
	</div>

</div>

<style type="text/css">
#guidebox {}
#guidebox h1 {font-family:"malgun gothic",dotum;font-size:22px;padding:0 0 10px 0;margin:0 0 30px 0;border-bottom:#dfdfdf solid 1px;}
#guidebox ul {}
#guidebox li {padding:5px 0 5px 0;color:#999;}
#guidebox .back {border-top:#dfdfdf solid 1px;margin:30px 0 0 0;padding:20px 0 30px 0;text-align:right;}
</style>
