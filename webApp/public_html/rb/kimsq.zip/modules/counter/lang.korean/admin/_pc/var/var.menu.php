<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['data'] = '자료분석';
$d['amenu']['main'] = '접속통계';
$d['amenu']['browser'] = '브라우져';
$d['amenu']['inkeyword'] = '내부키워드';
$d['amenu']['outkeyword'] = '유입키워드';
$d['amenu']['referer'] = '접속경로';
?>