<?php
if(!defined('__KIMS__')) exit;
?>