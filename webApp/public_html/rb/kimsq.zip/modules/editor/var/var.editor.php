<?php
$d['editor']['skin'] = "default";
$d['editor']['compo'] = "";
?>