<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['main'] = '연결도메인 관리';
?>