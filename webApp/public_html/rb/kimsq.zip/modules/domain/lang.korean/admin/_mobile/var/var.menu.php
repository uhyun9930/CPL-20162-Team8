<?php
$d['amenu']['main'] = '연결도메인 관리';
?>