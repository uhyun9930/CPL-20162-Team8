<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['main'] = '파일메니져';
?>