<?php
$d['admin']['themepc'] = "default";
$d['admin']['thememobile'] = "default";
$d['admin']['autoclose'] = "1";
$d['admin']['version'] = "1.2.2";
$d['admin']['hidepannel'] = "";
$d['admin']['pannellink'] = "";
$d['admin']['cache_flag'] = "month";
$d['admin']['http_port'] = "80";
$d['admin']['ssl_type'] = "";
$d['admin']['ssl_port'] = "";
$d['admin']['ssl_menu'] = "";
$d['admin']['ssl_page'] = "join,login,";
$d['admin']['ssl_bbs'] = "";
$d['admin']['ssl_module'] = "zipsearch,";
?>