<?php
if($my['uid']==1)
{
	$d['amenu']['config'] = '환경/테마';
	$d['amenu']['switch'] = '스위치';
	$d['amenu']['update'] = '업데이트';
	$d['amenu']['admin'] = '관리자';
}
$d['amenu']['bookmark'] = '북마크';
?>