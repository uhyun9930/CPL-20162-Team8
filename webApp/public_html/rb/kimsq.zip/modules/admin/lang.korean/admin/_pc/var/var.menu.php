<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['main'] = '데스크';
if($my['uid']==1)
{
	$d['amenu']['config'] = '환경/테마';
	$d['amenu']['switch'] = '스위치';
	$d['amenu']['update'] = '업데이트';
	$d['amenu']['admin'] = '관리자';
}
$d['amenu']['bookmark'] = '북마크';
$d['amenu']['seo'] = 'SEO';
$d['amenu']['ssl'] = 'SSL';
$d['amenu']['security'] = '보안';
?>