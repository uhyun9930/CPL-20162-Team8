<?php
$d['comment']['skin_main'] = "_pc/list01";
$d['comment']['skin_mobile'] = "_mobile/list01";
$d['comment']['badword'] = "시발,씨발,개새끼,개세끼,개쉐이,지랄,니미,좆,좃,조낸,죽어,쪽바리,짱개,떼놈,";
$d['comment']['badword_action'] = "0";
$d['comment']['badword_escape'] = "*";
$d['comment']['singo_del'] = "";
$d['comment']['singo_del_num'] = "20";
$d['comment']['singo_del_act'] = "1";
$d['comment']['onelinedel'] = "";
$d['comment']['perm_write'] = "1";
$d['comment']['perm_upfile'] = "10";
$d['comment']['perm_photo'] = "1";
$d['comment']['edit_height'] = "50";
$d['comment']['edit_tool'] = "1";
$d['comment']['use_hidden'] = "1";
$d['comment']['recnum'] = "20";
$d['comment']['use_subject'] = "1";
$d['comment']['give_point'] = "0";
$d['comment']['give_opoint'] = "0";
?>