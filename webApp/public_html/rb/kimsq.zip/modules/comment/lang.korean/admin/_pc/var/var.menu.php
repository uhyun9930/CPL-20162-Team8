<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['config'] = '환경설정';
$d['amenu']['main'] = '댓글';
$d['amenu']['oneline'] = '한줄의견';
?>