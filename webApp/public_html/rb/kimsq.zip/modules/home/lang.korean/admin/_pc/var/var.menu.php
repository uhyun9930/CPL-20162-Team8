<?php
$d['amenu']['_info'] = '모듈정보';
$d['amenu']['main'] = '사이트';
$d['amenu']['menu'] = '메뉴';
$d['amenu']['page'] = '페이지';
?>