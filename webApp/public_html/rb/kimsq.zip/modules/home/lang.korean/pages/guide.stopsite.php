
<div id="guidebox<?php echo $g['mobile']?'_mobile':''?>">

	<h1>서비스 안내</h1>
	
	<ul>
	<li>서비스가 일시적으로 중단되었거나 서버 작업중에 있습니다.</li>
	<li>작업이 완료되는대로 재오픈될 예정입니다.</li>
	</ul>

</div>
