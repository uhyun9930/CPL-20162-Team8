

<div id="pagebox">

	<div class="title">[안내] 페이지를 찾을 수 없습니다.</div>
	
	<div class="message">
		요청하신 페이지는 존재하지 않거나 컨텐츠연결이 잘못된 상태입니다.<br />
		관리자로 로그인하시면 요청하신 페이지를 직접 만드시거나 페이지에 대한 세부설정을 확인하실 수 있습니다.<br />
		<br />
		<a href="<?php echo RW('m=admin')?>" class="u">관리자로 로그인하기</a>
	</div>

</div>
